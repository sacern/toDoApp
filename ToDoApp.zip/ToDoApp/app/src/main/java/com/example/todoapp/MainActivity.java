package com.example.todoapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;


import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> toDoItems = new ArrayList<>();
    ArrayAdapter<String> anArrayAdapter;
    ListView lvItems;
    EditText etEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //readItems();
        Log.v("Main", "Populate list");
        populateArrayItems();

        Log.v("Main", "Before adapter setup");

        anArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, toDoItems);
        Log.v("Main", "after adapter setup");

        lvItems = (ListView) findViewById(R.id.lvitems);
        lvItems.setAdapter(anArrayAdapter);
        etEditText = (EditText) findViewById(R.id.txtItem);
        lvItems.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                toDoItems.remove(position);
                anArrayAdapter.notifyDataSetChanged();

                return true;
            }
        });

        Log.v("Main", "One");
    }

    private void readItems(){

        File filesDir = getFilesDir();
        File file = new File(filesDir,"todo.txt");

        try{
            toDoItems = new ArrayList<>(FileUtils.readLines(file));
        }
        catch (IOException e){
            e.printStackTrace();
    }}

    private void writeItems(){

        try{

        File filesDir = getFilesDir();
        File file = new File(filesDir,"todo.txt");
        if (!file.exists()) {
            file.createNewFile();
        }
            FileUtils.writeLines(file, toDoItems);
        }
        catch (IOException e){
        }}


    public void populateArrayItems() {
        readItems();



    }
    public void onAddItem(View view) {
        anArrayAdapter.add(etEditText.getText().toString());
        etEditText.setText("");
        writeItems();
    }

    static final int REQUEST_IMAGE_CAPTURE =1;




   String mCurrentPhotoPath;


    private File createImageFile() throws IOException{
        //Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);

        File image = File.createTempFile(
                imageFileName,
                ".jpg",
                storageDir

        );

        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }

    static final int REQUEST_TAKE_PHOTO = 1;

    private void dispatchTakePictureIntent(){

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (takePictureIntent.resolveActivity(getPackageManager())!=null) {


            }
        }
    }




